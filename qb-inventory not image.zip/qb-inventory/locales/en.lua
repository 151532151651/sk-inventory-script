-- Development Groupe
-- https://discord.gg/YFvBJPadda
-- By SK / SKANDI DEV


local L0_1, L1_1, L2_1, L3_1
L0_1 = {}
L1_1 = {}
L1_1.crafting = "Crafting..."
L1_1.snowballs = "Collecting snowballs.."
L0_1.progress = L1_1
L1_1 = {}
L1_1.failed = "Failed"
L1_1.canceled = "Canceled"
L1_1.vlocked = "Vehicle Locked"
L1_1.notowned = "You do not own this item!"
L1_1.missitem = "You don't have this item!"
L1_1.nonb = "No one nearby!"
L1_1.noaccess = "Not Accessible"
L1_1.nosell = "You can't sell this item.."
L1_1.itemexist = "Item doesn't exist??"
L1_1.notencash = "You don't have enough cash.."
L1_1.noitem = "You don't have the right items.."
L1_1.gsitem = "You can't give yourself an item?"
L1_1.tftgitem = "You are too far away to give items!"
L1_1.infound = "Item you tried giving not found!"
L1_1.iifound = "Incorrect item found try again!"
L1_1.gitemrec = "You Received "
L1_1.gitemfrom = " From "
L1_1.gitemyg = "You gave "
L1_1.gitinvfull = "The other players inventory is full!"
L1_1.giymif = "Your inventory is full!"
L1_1.gitydhei = "You do not have enough of the item"
L1_1.gitydhitt = "You do not have enough items to transfer"
L1_1.navt = "Not a valid type.."
L1_1.anfoc = "Arguments not filled out correctly.."
L1_1.yhg = "You Have Given "
L1_1.cgitem = "Can't give item!"
L1_1.idne = "Item Does Not Exist"
L1_1.pdne = "Player Is Not Online"
L0_1.notify = L1_1
L1_1 = {}
L1_1.opn_inv = "Open Inventory"
L1_1.tog_slots = "Toggles keybind slots"
L1_1.use_item = "Uses the item in slot "
L0_1.inf_mapping = L1_1
L1_1 = {}
L1_1.vending = "Vending Machine"
L1_1.craft = "Craft"
L1_1.o_bag = "Open Bag"
L0_1.menu = L1_1
L1_1 = {}
L1_1.craft = "~g~E~w~ - Craft"
L0_1.interaction = L1_1
L1_1 = {}
L1_1.craft = "Crafting"
L1_1.a_craft = "Attachment Crafting"
L0_1.label = L1_1
L1_1 = Locale
L2_1 = L1_1
L1_1 = L1_1.new
L3_1 = {}
L3_1.phrases = L0_1
L3_1.warnOnMissing = true
L1_1 = L1_1(L2_1, L3_1)
Lang = L1_1


-- Development Groupe
-- https://discord.gg/YFvBJPadda
-- By SK / SKANDI DEV
