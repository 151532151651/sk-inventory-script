-- Development Groupe
-- https://discord.gg/YFvBJPadda
-- By SK / SKANDI DEV


Config = {}

Config.UseTarget = GetConvar('UseTarget', 'false') == 'true' -- Use qb-target interactions

Config.MaxInventoryWeight = 120000  -- 120kg in grams
Config.MaxInventorySlots = 41

Config.CleanupDropTime = 15 * 60    -- seconds
Config.MaxDropViewDistance = 12.5
Config.UseItemDrop = false
Config.ItemDropObject = `prop_nigel_bag_pickup`

Config.VendingObjects = {
    "prop_vend_soda_01",
    "prop_vend_soda_02",
    "prop_vend_water_01"
}
Config.VendingObjects2 = { "prop_vend_snak_01" }
Config.BinObjects = { "prop_bin_05a" }
Config.CraftingObject = `prop_toolchest_05`

Config.VendingItem = {
    [1] = { name = "kurkakola", price = 110, amount = 50, type = "item", slot = 1 },
    [2] = { name = "water_bottle", price = 110, amount = 50, type = "item", slot = 2 }
}
Config.VendingSnaksItem = {
    [1] = { name = "tosti", price = 100, amount = 50, type = "item", slot = 1 },
    [2] = { name = "twerks_candy", price = 80, amount = 50, type = "item", slot = 2 }
}

Config.CraftingItems = {
    [1] = { name = "lockpick", amount = 50, costs = { metalscrap = 22, plastic = 32 }, threshold = 0, points = 1 },
    [2] = { name = "screwdriverset", amount = 50, costs = { metalscrap = 30, plastic = 42 }, threshold = 0, points = 2 },
    [3] = { name = "electronickit", amount = 50, costs = { metalscrap = 30, plastic = 45, aluminum = 28 }, threshold = 0, points = 3 },
    [4] = { name = "radioscanner", amount = 50, costs = { electronickit = 2, plastic = 52, steel = 40 }, threshold = 0, points = 4 },
    [5] = { name = "gatecrack", amount = 50, costs = { metalscrap = 10, plastic = 50, aluminum = 30, iron = 17, electronickit = 2 }, threshold = 110, points = 5 },
    [6] = { name = "handcuffs", amount = 50, costs = { metalscrap = 36, steel = 24, aluminum = 28 }, threshold = 160, points = 6 },
    [7] = { name = "repairkit", amount = 50, costs = { metalscrap = 32, steel = 43, plastic = 61 }, threshold = 200, points = 7 },
    [8] = { name = "pistol_ammo", amount = 50, costs = { metalscrap = 50, steel = 37, copper = 26 }, threshold = 250, points = 8 },
    [9] = { name = "ironoxide", amount = 50, costs = { iron = 60, glass = 30 }, threshold = 300, points = 9 },
    [10] = { name = "aluminumoxide", amount = 50, costs = { aluminum = 60, glass = 30 }, threshold = 300, points = 10 },
    [11] = { name = "armor", amount = 50, costs = { iron = 33, steel = 44, plastic = 55, aluminum = 22 }, threshold = 350, points = 11 },
    [12] = { name = "drill", amount = 50, costs = { iron = 50, steel = 50, screwdriverset = 3, advancedlockpick = 2 }, threshold = 1750, points = 12 }
}

Config.AttachmentCraftingLocation = vector3(88.91, 3743.88, 40.77)

Config.AttachmentCrafting = {
    items = {
        [1] = { name = "pistol_extendedclip", amount = 50, costs = { metalscrap = 140, steel = 250, rubber = 60 }, threshold = 0, points = 1 },
        [2] = { name = "pistol_suppressor", amount = 50, costs = { metalscrap = 165, steel = 285, rubber = 75 }, threshold = 10, points = 2 },
        [3] = { name = "smg_extendedclip", amount = 50, costs = { metalscrap = 190, steel = 305, rubber = 85 }, threshold = 25, points = 3 },
        [4] = { name = "microsmg_extendedclip", amount = 50, costs = { metalscrap = 205, steel = 340, rubber = 110 }, threshold = 50, points = 4 },
        [5] = { name = "smg_drum", amount = 50, costs = { metalscrap = 230, steel = 365, rubber = 130 }, threshold = 75, points = 5 },
        [6] = { name = "smg_scope", amount = 50, costs = { metalscrap = 255, steel = 390, rubber = 145 }, threshold = 100, points = 6 },
        [7] = { name = "assaultrifle_extendedclip", amount = 50, costs = { metalscrap = 270, steel = 435, rubber = 155, smg_extendedclip = 1 }, threshold = 150, points = 7 },
        [8] = { name = "assaultrifle_drum", amount = 50, costs = { metalscrap = 300, steel = 469, rubber = 170, smg_extendedclip = 2 }, threshold = 200, points = 8 }
    }
}

BackEngineVehicles = {
    [`ninef`] = true, [`adder`] = true, [`vagner`] = true, [`t20`] = true, [`infernus`] = true,
    [`zentorno`] = true, [`reaper`] = true, [`comet2`] = true, [`comet3`] = true, [`jester`] = true,
    [`jester2`] = true, [`cheetah`] = true, [`cheetah2`] = true, [`prototipo`] = true, [`turismor`] = true,
    [`pfister811`] = true, [`ardent`] = true, [`nero`] = true, [`nero2`] = true, [`tempesta`] = true,
    [`vacca`] = true, [`bullet`] = true, [`osiris`] = true, [`entityxf`] = true, [`turismo2`] = true,
    [`fmj`] = true, [`re7b`] = true, [`tyrus`] = true, [`italigtb`] = true, [`penetrator`] = true,
    [`monroe`] = true, [`ninef2`] = true, [`stingergt`] = true, [`surfer`] = true, [`surfer2`] = true,
    [`gp1`] = true, [`autarch`] = true, [`tyrant`] = true
}

Config.MaximumAmmoValues = {
    pistol = 250, smg = 250, shotgun = 200, rifle = 250, stungun = 10
}

-- Trunk space per vehicle class
Config.TrunkSpace = {
    default = { slots = 35, maxWeight = 60000 },
    [0] = { slots = 30, maxWeight = 38000 },
    [1] = { slots = 40, maxWeight = 50000 },
    [2] = { slots = 50, maxWeight = 75000 },
    [3] = { slots = 35, maxWeight = 42000 },
    [4] = { slots = 30, maxWeight = 38000 },
    [5] = { slots = 25, maxWeight = 30000 },
    [6] = { slots = 25, maxWeight = 30000 },
    [7] = { slots = 25, maxWeight = 30000 },
    [8] = { slots = 15, maxWeight = 15000 },
    [9] = { slots = 35, maxWeight = 60000 },
    [12] = { slots = 35, maxWeight = 350000 },
    [13] = { slots = 0, maxWeight = 0 },
    [14] = { slots = 50, maxWeight = 350000 },
    [15] = { slots = 50, maxWeight = 350000 },
    [16] = { slots = 50, maxWeight = 350000 }
}

-- Development Groupe
-- https://discord.gg/YFvBJPadda
-- By SK / SKANDI DEV
