-- Development Groupe
-- https://discord.gg/YFvBJPadda
-- By SK / SKANDI DEV


fx_version 'cerulean'
game 'gta5'

author "QB-Inventory_MADE BY SK"
description 'SKANDI MADE'
version '1.0'

shared_scripts {
	'@qb-core/shared/locale.lua',
	'locales/en.lua', -- Change to the language you want
	'config.lua',
	'@qb-weapons/config.lua'
}

server_scripts {
	'@oxmysql/lib/MySQL.lua',
	'server/main.lua',
	'server/decay.lua'
}

client_script 'client/main.lua'

ui_page {
	'html/ui.html'
}

escrow_ignore {
	'server/main.lua',
	'server/decay.lua'
}


files {
	'html/ui.html',
	'html/css/main.css',
	'html/js/app.js',
	'html/images/*.svg',
	'html/images/*.png',
	'html/images/*.jpg',
	'html/inventory_images/*.png',
	'html/*.png',
	'html/ammo_images/*.png',
	'html/attachment_images/*.png',
	'html/*.ttf'
}

dependency 'qb-weapons'

lua54 'yes'
dependency '/assetpacks'

-- Development Groupe
-- https://discord.gg/YFvBJPadda
-- By SK / SKANDI DEV
