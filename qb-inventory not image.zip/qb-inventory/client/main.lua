-- Development Groupe
-- https://discord.gg/YFvBJPadda
-- By SK / SKANDI DEV


--#region Variables
local QBCore = exports['qb-core']:GetCoreObject()
local PlayerData = {}
local inInventory = false
local currentWeapon = nil
local currentOtherInventory = nil
local Drops = {}
local CurrentDrop = nil
local DropsNear = {}
local CurrentVehicle = nil
local CurrentGlovebox = nil
local CurrentStash = nil
local isCrafting = false
local isHotbar = false
local WeaponAttachments = {}
local itemInfos = {}
local showBlur = true
--#endregion

--#region Helper Functions
local function GetFirstSlotByItem(items, itemName)
    if not items then return nil end
    for slot, item in pairs(items) do
        if item and item.name:lower() == itemName:lower() then
            return tonumber(slot)
        end
    end
    return nil
end

local function GetItemByName(itemName)
    if not PlayerData or not PlayerData.items then return nil end
    itemName = tostring(itemName):lower()
    local slot = GetFirstSlotByItem(PlayerData.items, itemName)
    if slot then return PlayerData.items[slot] end
    return nil
end

local function HasItem(items, amount)
    if not PlayerData or type(PlayerData.items) ~= "table" then return false end
    local isTable = type(items) == 'table'
    local isArray = isTable and table.type(items) == 'array' or false
    local totalItems = #items
    local count = 0
    local kvIndex = 2
    if isTable and not isArray then
        totalItems = 0
        for _ in pairs(items) do totalItems = totalItems + 1 end
        kvIndex = 1
    end
    for _, itemData in pairs(PlayerData.items) do
        if isTable then
            for k, v in pairs(items) do
                local itemKV = {k, v}
                if itemData and itemData.name == itemKV[kvIndex] and ((amount and itemData.amount >= amount) or (not isArray and itemData.amount >= v) or (not amount and isArray)) then
                    count = count + 1
                end
            end
            if count == totalItems then return true end
        else
            if itemData and itemData.name == items and (not amount or (itemData and amount and itemData.amount >= amount)) then
                return true
            end
        end
    end
    return false
end

local function GetClosestVending()
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    local object = nil
    for _, machine in pairs(Config.VendingObjects) do
        local ClosestObject = GetClosestObjectOfType(pos.x, pos.y, pos.z, 0.75, GetHashKey(machine), 0, 0, 0)
        if ClosestObject ~= 0 and object == nil then object = ClosestObject end
    end
    return object
end

local function DrawText3Ds(x, y, z, text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(true)
    AddTextComponentString(text)
    SetDrawOrigin(x, y, z, 0)
    DrawText(0.0, 0.0)
    local factor = string.len(text) / 370
    DrawRect(0.0, 0.0125, 0.017 + factor, 0.03, 0, 0, 0, 75)
    ClearDrawOrigin()
end

local function LoadAnimDict(dict)
    if HasAnimDictLoaded(dict) then return end
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do Wait(10) end
end

local function FormatWeaponAttachments(itemdata)
    local attachments = {}
    itemdata.name = itemdata.name:upper()
    if itemdata.info.attachments ~= nil and next(itemdata.info.attachments) ~= nil then
        for _, v in pairs(itemdata.info.attachments) do
            attachments[#attachments+1] = {
                attachment = v.item,
                label = v.label,
                image = QBCore.Shared.Items[v.item].image,
                component = v.component
            }
        end
    end
    return attachments
end

local function IsBackEngine(vehModel)
    return BackEngineVehicles[vehModel]
end

local function OpenTrunk()
    local vehicle = QBCore.Functions.GetClosestVehicle()
    LoadAnimDict("amb@prop_human_bum_bin@idle_b")
    TaskPlayAnim(PlayerPedId(), "amb@prop_human_bum_bin@idle_b", "idle_d", 4.0, 4.0, -1, 50, 0, false, false, false)
    if IsBackEngine(GetEntityModel(vehicle)) then
        SetVehicleDoorOpen(vehicle, 4, false, false)
    else
        SetVehicleDoorOpen(vehicle, 5, false, false)
    end
end

local function CloseTrunk()
    local vehicle = QBCore.Functions.GetClosestVehicle()
    LoadAnimDict("amb@prop_human_bum_bin@idle_b")
    TaskPlayAnim(PlayerPedId(), "amb@prop_human_bum_bin@idle_b", "exit", 4.0, 4.0, -1, 50, 0, false, false, false)
    if IsBackEngine(GetEntityModel(vehicle)) then
        SetVehicleDoorShut(vehicle, 4, false)
    else
        SetVehicleDoorShut(vehicle, 5, false)
    end
end

local function closeInventory()
    SendNUIMessage({ action = "close" })
    SetNuiFocus(false, false)
    inInventory = false
    if showBlur then TriggerScreenblurFadeOut(1000) end
end

local function ToggleHotbar(toggle)
    local HotbarItems = {
        [1] = PlayerData.items and PlayerData.items[1] or nil,
        [2] = PlayerData.items and PlayerData.items[2] or nil,
        [3] = PlayerData.items and PlayerData.items[3] or nil,
        [4] = PlayerData.items and PlayerData.items[4] or nil,
        [5] = PlayerData.items and PlayerData.items[5] or nil,
        [41] = PlayerData.items and PlayerData.items[41] or nil,
    }
    if toggle then
        SendNUIMessage({ action = "toggleHotbar", open = true, items = HotbarItems })
    else
        SendNUIMessage({ action = "toggleHotbar", open = false })
    end
end

local function openAnim()
    LoadAnimDict('pickup_object')
    TaskPlayAnim(PlayerPedId(),'pickup_object', 'putdown_low', 5.0, 1.5, 1.0, 48, 0.0, 0, 0, 0)
end

local function ItemsToItemInfo()
    local itemInfos = {
        [1] = {costs = QBCore.Shared.Items["metalscrap"]["label"] .. ": 22x, " ..QBCore.Shared.Items["plastic"]["label"] .. ": 32x."},
        [2] = {costs = QBCore.Shared.Items["metalscrap"]["label"] .. ": 30x, " ..QBCore.Shared.Items["plastic"]["label"] .. ": 42x."},
        [3] = {costs = QBCore.Shared.Items["metalscrap"]["label"] .. ": 30x, " ..QBCore.Shared.Items["plastic"]["label"] .. ": 45x, "..QBCore.Shared.Items["aluminum"]["label"] .. ": 28x."},
        [4] = {costs = QBCore.Shared.Items["electronickit"]["label"] .. ": 2x, " ..QBCore.Shared.Items["plastic"]["label"] .. ": 52x, "..QBCore.Shared.Items["steel"]["label"] .. ": 40x."},
        [5] = {costs = QBCore.Shared.Items["metalscrap"]["label"] .. ": 10x, " ..QBCore.Shared.Items["plastic"]["label"] .. ": 50x, "..QBCore.Shared.Items["aluminum"]["label"] .. ": 30x, "..QBCore.Shared.Items["iron"]["label"] .. ": 17x, "..QBCore.Shared.Items["electronickit"]["label"] .. ": 1x."},
        [6] = {costs = QBCore.Shared.Items["metalscrap"]["label"] .. ": 36x, " ..QBCore.Shared.Items["steel"]["label"] .. ": 24x, "..QBCore.Shared.Items["aluminum"]["label"] .. ": 28x."},
        [7] = {costs = QBCore.Shared.Items["metalscrap"]["label"] .. ": 32x, " ..QBCore.Shared.Items["steel"]["label"] .. ": 43x, "..QBCore.Shared.Items["plastic"]["label"] .. ": 61x."},
        [8] = {costs = QBCore.Shared.Items["metalscrap"]["label"] .. ": 50x, " ..QBCore.Shared.Items["steel"]["label"] .. ": 37x, "..QBCore.Shared.Items["copper"]["label"] .. ": 26x."},
        [9] = {costs = QBCore.Shared.Items["iron"]["label"] .. ": 60x, " ..QBCore.Shared.Items["glass"]["label"] .. ": 30x."},
        [10] = {costs = QBCore.Shared.Items["aluminum"]["label"] .. ": 60x, " ..QBCore.Shared.Items["glass"]["label"] .. ": 30x."},
        [11] = {costs = QBCore.Shared.Items["iron"]["label"] .. ": 33x, " ..QBCore.Shared.Items["steel"]["label"] .. ": 44x, "..QBCore.Shared.Items["plastic"]["label"] .. ": 55x, "..QBCore.Shared.Items["aluminum"]["label"] .. ": 22x."},
        [12] = {costs = QBCore.Shared.Items["iron"]["label"] .. ": 50x, " ..QBCore.Shared.Items["steel"]["label"] .. ": 50x, "..QBCore.Shared.Items["screwdriverset"]["label"] .. ": 3x, "..QBCore.Shared.Items["advancedlockpick"]["label"] .. ": 2x."},
    }
    local items = {}
    for _, item in pairs(Config.CraftingItems) do
        local itemInfo = QBCore.Shared.Items[item.name:lower()]
        items[item.slot] = {
            name = itemInfo["name"], amount = tonumber(item.amount), info = itemInfos[item.slot],
            label = itemInfo["label"], description = itemInfo["description"] or "", weight = itemInfo["weight"],
            type = itemInfo["type"], unique = itemInfo["unique"], useable = itemInfo["useable"],
            image = itemInfo["image"], slot = item.slot, costs = item.costs, threshold = item.threshold, points = item.points,
        }
    end
    Config.CraftingItems = items
end

local function SetupAttachmentItemsInfo()
    local itemInfos = {
        [1] = {costs = QBCore.Shared.Items["metalscrap"]["label"] .. ": 140x, " .. QBCore.Shared.Items["steel"]["label"] .. ": 250x, " .. QBCore.Shared.Items["rubber"]["label"] .. ": 60x"},
        [2] = {costs = QBCore.Shared.Items["metalscrap"]["label"] .. ": 165x, " .. QBCore.Shared.Items["steel"]["label"] .. ": 285x, " .. QBCore.Shared.Items["rubber"]["label"] .. ": 75x"},
        [3] = {costs = QBCore.Shared.Items["metalscrap"]["label"] .. ": 190x, " .. QBCore.Shared.Items["steel"]["label"] .. ": 305x, " .. QBCore.Shared.Items["rubber"]["label"] .. ": 85x"},
        [4] = {costs = QBCore.Shared.Items["metalscrap"]["label"] .. ": 205x, " .. QBCore.Shared.Items["steel"]["label"] .. ": 340x, " .. QBCore.Shared.Items["rubber"]["label"] .. ": 110x"},
        [5] = {costs = QBCore.Shared.Items["metalscrap"]["label"] .. ": 230x, " .. QBCore.Shared.Items["steel"]["label"] .. ": 365x, " .. QBCore.Shared.Items["rubber"]["label"] .. ": 130x"},
        [6] = {costs = QBCore.Shared.Items["metalscrap"]["label"] .. ": 255x, " .. QBCore.Shared.Items["steel"]["label"] .. ": 390x, " .. QBCore.Shared.Items["rubber"]["label"] .. ": 145x"},
        [7] = {costs = QBCore.Shared.Items["metalscrap"]["label"] .. ": 270x, " .. QBCore.Shared.Items["steel"]["label"] .. ": 435x, " .. QBCore.Shared.Items["rubber"]["label"] .. ": 155x"},
        [8] = {costs = QBCore.Shared.Items["metalscrap"]["label"] .. ": 300x, " .. QBCore.Shared.Items["steel"]["label"] .. ": 469x, " .. QBCore.Shared.Items["rubber"]["label"] .. ": 170x"},
    }
    local items = {}
    for _, item in pairs(Config.AttachmentCrafting["items"]) do
        local itemInfo = QBCore.Shared.Items[item.name:lower()]
        items[item.slot] = {
            name = itemInfo["name"], amount = tonumber(item.amount), info = itemInfos[item.slot],
            label = itemInfo["label"], description = itemInfo["description"] or "", weight = itemInfo["weight"],
            unique = itemInfo["unique"], useable = itemInfo["useable"], image = itemInfo["image"],
            slot = item.slot, costs = item.costs, threshold = item.threshold, points = item.points,
        }
    end
    Config.AttachmentCrafting["items"] = items
end

-- إصلاح الدوال التي تستخدم metadata مع التحقق من وجودها
local function GetThresholdItems()
    if not PlayerData or not PlayerData.metadata then return {} end
    ItemsToItemInfo()
    local items = {}
    for k in pairs(Config.CraftingItems) do
        if PlayerData.metadata["craftingrep"] >= Config.CraftingItems[k].threshold then
            items[k] = Config.CraftingItems[k]
        end
    end
    return items
end

local function GetAttachmentThresholdItems()
    if not PlayerData or not PlayerData.metadata then return {} end
    SetupAttachmentItemsInfo()
    local items = {}
    for k in pairs(Config.AttachmentCrafting["items"]) do
        if PlayerData.metadata["attachmentcraftingrep"] >= Config.AttachmentCrafting["items"][k].threshold then
            items[k] = Config.AttachmentCrafting["items"][k]
        end
    end
    return items
end

local function RemoveNearbyDrop(index)
    if not DropsNear[index] then return end
    local dropItem = DropsNear[index].object
    if DoesEntityExist(dropItem) then DeleteEntity(dropItem) end
    DropsNear[index] = nil
    if not Drops[index] then return end
    Drops[index].object = nil
    Drops[index].isDropShowing = nil
end

local function RemoveAllNearbyDrops()
    for k in pairs(DropsNear) do RemoveNearbyDrop(k) end
end

local function CreateItemDrop(index)
    local dropItem = CreateObject(Config.ItemDropObject, DropsNear[index].coords.x, DropsNear[index].coords.y, DropsNear[index].coords.z, false, false, false)
    DropsNear[index].object = dropItem
    DropsNear[index].isDropShowing = true
    PlaceObjectOnGroundProperly(dropItem)
    FreezeEntityPosition(dropItem, true)
    if Config.UseTarget then
        exports['qb-target']:AddTargetEntity(dropItem, {
            options = { { icon = 'fas fa-backpack', label = Lang:t("menu.o_bag"), action = function() TriggerServerEvent("inventory:server:OpenInventory", "drop", index) end } },
            distance = 2.5,
        })
    end
end
--#endregion

--#region NUI Callbacks
RegisterNUICallback('RobMoney', function(data, cb) TriggerServerEvent("police:server:RobPlayer", data.TargetId) cb('ok') end)
RegisterNUICallback('Notify', function(data, cb) QBCore.Functions.Notify(data.message, data.type) cb('ok') end)
RegisterNUICallback('GetWeaponData', function(cData, cb) cb({ WeaponData = QBCore.Shared.Items[cData.weapon], AttachmentData = FormatWeaponAttachments(cData.ItemData) }) end)

RegisterNUICallback('RemoveAttachment', function(data, cb)
    local ped = PlayerPedId()
    local WeaponData = QBCore.Shared.Items[data.WeaponData.name]
    QBCore.Functions.TriggerCallback('weapons:server:RemoveAttachment', function(NewAttachments)
        if NewAttachments ~= false then
            local attachments = {}
            RemoveWeaponComponentFromPed(ped, GetHashKey(data.WeaponData.name), GetHashKey(data.AttachmentData.component))
            for _, v in pairs(NewAttachments) do
                attachments[#attachments+1] = { attachment = v.item, label = v.label, image = QBCore.Shared.Items[v.item].image }
            end
            cb({ Attachments = attachments, WeaponData = WeaponData })
        else
            RemoveWeaponComponentFromPed(ped, GetHashKey(data.WeaponData.name), GetHashKey(data.AttachmentData.component))
            cb({})
        end
    end, data.AttachmentData, data.WeaponData)
end)

RegisterNUICallback('getCombineItem', function(data, cb) cb(QBCore.Shared.Items[data.item]) end)

RegisterNUICallback("CloseInventory", function(_, cb)
    if currentOtherInventory == "none-inv" then
        CurrentDrop = nil; CurrentVehicle = nil; CurrentGlovebox = nil; CurrentStash = nil
        SetNuiFocus(false, false); inInventory = false; if showBlur then TriggerScreenblurFadeOut(1000) end; ClearPedTasks(PlayerPedId())
        cb('ok')
        return
    end
    if CurrentVehicle ~= nil then
        CloseTrunk()
        TriggerServerEvent("inventory:server:SaveInventory", "trunk", CurrentVehicle)
        CurrentVehicle = nil
    elseif CurrentGlovebox ~= nil then
        TriggerServerEvent("inventory:server:SaveInventory", "glovebox", CurrentGlovebox)
        CurrentGlovebox = nil
    elseif CurrentStash ~= nil then
        TriggerServerEvent("inventory:server:SaveInventory", "stash", CurrentStash)
        CurrentStash = nil
    else
        TriggerServerEvent("inventory:server:SaveInventory", "drop", CurrentDrop)
        CurrentDrop = nil
    end
    Wait(50)
    if showBlur then TriggerScreenblurFadeOut(1000) end
    SetNuiFocus(false, false)
    inInventory = false
    cb('ok')
end)

RegisterNUICallback("UseItem", function(data, cb) TriggerServerEvent("inventory:server:UseItem", data.inventory, data.item) cb('ok') end)
RegisterNUICallback("combineItem", function(data, cb) Wait(150) TriggerServerEvent('inventory:server:combineItem', data.reward, data.fromItem, data.toItem) cb('ok') end)

RegisterNUICallback('combineWithAnim', function(data, cb)
    local ped = PlayerPedId()
    local combineData = data.combineData
    local aDict = combineData.anim.dict
    local aLib = combineData.anim.lib
    local animText = combineData.anim.text
    local animTimeout = combineData.anim.timeOut
    QBCore.Functions.Progressbar("combine_anim", animText, animTimeout, false, true, {
        disableMovement = false, disableCarMovement = true, disableMouse = false, disableCombat = true,
    }, { animDict = aDict, anim = aLib, flags = 16 }, {}, {}, function()
        StopAnimTask(ped, aDict, aLib, 1.0)
        TriggerServerEvent('inventory:server:combineItem', combineData.reward, data.requiredItem, data.usedItem)
    end, function()
        StopAnimTask(ped, aDict, aLib, 1.0)
        QBCore.Functions.Notify(Lang:t("notify.failed"), "error")
    end)
    cb('ok')
end)

RegisterNUICallback("SetInventoryData", function(data, cb) TriggerServerEvent("inventory:server:SetInventoryData", data.fromInventory, data.toInventory, data.fromSlot, data.toSlot, data.fromAmount, data.toAmount) cb('ok') end)
RegisterNUICallback("PlayDropSound", function(_, cb) PlaySound(-1, "CLICK_BACK", "WEB_NAVIGATION_SOUNDS_PHONE", 0, 0, 1) cb('ok') end)
RegisterNUICallback("PlayDropFail", function(_, cb) PlaySound(-1, "Place_Prop_Fail", "DLC_Dmod_Prop_Editor_Sounds", 0, 0, 1) cb('ok') end)

RegisterNUICallback("GiveItem", function(data, cb)
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local closestPlayers = {}
    local allPlayers = GetActivePlayers()
    for _, clientId in ipairs(allPlayers) do
        local targetPed = GetPlayerPed(clientId)
        if targetPed ~= 0 then
            local targetCoords = GetEntityCoords(targetPed)
            local distance = #(playerCoords - targetCoords)
            if distance <= 2.5 and clientId ~= PlayerId() then
                table.insert(closestPlayers, { id = clientId, serverId = GetPlayerServerId(clientId), name = GetPlayerName(clientId), distance = distance })
            end
        end
    end
    if #closestPlayers == 0 then
        QBCore.Functions.Notify(Lang:t("notify.nonb"), "error")
        cb('ok')
        return
    end
    table.sort(closestPlayers, function(a, b) return a.distance < b.distance end)
    local menuItems = {}
    for _, player in ipairs(closestPlayers) do
        table.insert(menuItems, { header = player.name, txt = "ID: " .. player.serverId .. " | Distance: " .. string.format("%.1f", player.distance) .. "m", params = { isServer = true, event = "inventory:server:GiveItem", args = { playerId = player.serverId, name = data.item.name, amount = data.amount, slot = data.item.slot } } })
    end
    exports['qb-menu']:openMenu(menuItems)
    cb('ok')
end)
--#endregion

--#region Client Events
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    LocalPlayer.state:set("inv_busy", false, true)
    PlayerData = QBCore.Functions.GetPlayerData()
end)

RegisterNetEvent('QBCore:Client:OnPlayerUnload', function()
    LocalPlayer.state:set("inv_busy", true, true)
    PlayerData = {}
    closeInventory()
end)

RegisterNetEvent('QBCore:Client:UpdateObject', function()
    QBCore = exports['qb-core']:GetCoreObject()
end)

RegisterNetEvent('QBCore:Player:SetPlayerData', function(val)
    PlayerData = val
    -- إذا كانت الحقيبة مفتوحة، قم بتحديث الرصيد والوظيفة في الواجهة مباشرة
    if inInventory then
        SendNUIMessage({
            action = "updatePlayerInfo",
            cash = PlayerData.money and PlayerData.money.cash or 0,
            bank = PlayerData.money and PlayerData.money.bank or 0,
            job = (PlayerData.job and PlayerData.job.label) or "Unemployed",
            grade = (PlayerData.job and PlayerData.job.grade and PlayerData.job.grade.name) or ""
        })
    end
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    if Config.UseItemDrop then RemoveAllNearbyDrops() end
end)

RegisterNetEvent("qb-inventory:client:closeinv", closeInventory)

RegisterNetEvent('inventory:client:CheckOpenState', function(type, id, label)
    local name = QBCore.Shared.SplitStr(label, "-")[2]
    if (type == "stash" and name ~= CurrentStash) or (type == "trunk" and name ~= CurrentVehicle) or (type == "glovebox" and name ~= CurrentGlovebox) or (type == "drop" and name ~= CurrentDrop) then
        TriggerServerEvent('inventory:server:SetIsOpenState', false, type, id)
    end
end)

RegisterNetEvent('weapons:client:SetCurrentWeapon', function(data, bool) CurrentWeaponData = data or {} end)

RegisterNetEvent('inventory:client:ItemBox', function(itemData, type, amount) SendNUIMessage({ action = "itemBox", item = itemData, type = type, itemAmount = amount or 1 }) end)

RegisterNetEvent('inventory:client:requiredItems', function(items, bool)
    local itemTable = {}
    if bool then
        for k in pairs(items) do
            itemTable[#itemTable+1] = { item = items[k].name, label = QBCore.Shared.Items[items[k].name]["label"], image = items[k].image }
        end
    end
    SendNUIMessage({ action = "requiredItem", items = itemTable, toggle = bool })
end)

RegisterNetEvent('inventory:server:RobPlayer', function(TargetId) SendNUIMessage({ action = "RobMoney", TargetId = TargetId }) end)

-- الحدث الرئيسي لفتح الحقيبة (تم إصلاحه لجلب أحدث البيانات)
RegisterNetEvent('inventory:client:OpenInventory', function(PlayerAmmo, inventory, other, id)
    if IsEntityDead(PlayerPedId()) then return end
    Wait(100)
    ToggleHotbar(false)
    if showBlur then TriggerScreenblurFadeIn(300) end
    SetNuiFocus(true, true)
    if other then currentOtherInventory = other.name end

    -- 🔁 جلب أحدث بيانات اللاعب
    local freshPlayerData = QBCore.Functions.GetPlayerData()
    local cash = freshPlayerData.money and freshPlayerData.money.cash or 0
    local bank = freshPlayerData.money and freshPlayerData.money.bank or 0
    local firstname = (freshPlayerData.charinfo and freshPlayerData.charinfo.firstname) or "Unknown"
    local lastname = (freshPlayerData.charinfo and freshPlayerData.charinfo.lastname) or "Unknown"
    local job = (freshPlayerData.job and freshPlayerData.job.label) or "Unemployed"
    local grade = (freshPlayerData.job and freshPlayerData.job.grade and freshPlayerData.job.grade.name) or ""
    local citizenid = freshPlayerData.citizenid or "N/A"
    local metadata = freshPlayerData.metadata or {}
    local apartment = metadata.apartment or {}
    local room = apartment.room or "UNDEFINED"
    local floor = apartment.floor or "UNDEFINED"
    local building = apartment.building or "UNDEFINED"

    -- ✅ إصلاح الراتب: إذا كان nil أو غير موجود، نعطيه 0
    local payment = 0
    if freshPlayerData.job and freshPlayerData.job.payment then
        payment = freshPlayerData.job.payment
    end

    SendNUIMessage({
        action = "open",
        inventory = inventory,
        slots = Config.MaxInventorySlots,
        other = other,
        pid = GetPlayerServerId(PlayerId()),
        citizenid = citizenid,
        maxweight = Config.MaxInventoryWeight,
        Ammo = PlayerAmmo,
        firstname = firstname,
        lastname = lastname,
        playername = firstname .. " " .. lastname,
        job = job,
        grade = grade,
        payment = payment,   -- الراتب الآن رقم (0 إذا لم يوجد)
        room = room,
        floor = floor,
        bulding = building,
        cash = cash,
        bank = bank,
        maxammo = Config.MaximumAmmoValues,
    })
    inInventory = true
end)

RegisterNetEvent('inventory:client:CraftItems', function(itemName, itemCosts, amount, toSlot, points)
    local ped = PlayerPedId()
    SendNUIMessage({ action = "close" })
    isCrafting = true
    QBCore.Functions.Progressbar("repair_vehicle", Lang:t("progress.crafting"), (math.random(2000, 5000) * amount), false, true, { disableMovement = true, disableCarMovement = true, disableMouse = false, disableCombat = true }, { animDict = "mini@repair", anim = "fixing_a_player", flags = 16 }, {}, {}, function()
        StopAnimTask(ped, "mini@repair", "fixing_a_player", 1.0)
        TriggerServerEvent("inventory:server:CraftItems", itemName, itemCosts, amount, toSlot, points)
        TriggerEvent('inventory:client:ItemBox', QBCore.Shared.Items[itemName], 'add')
        isCrafting = false
    end, function()
        StopAnimTask(ped, "mini@repair", "fixing_a_player", 1.0)
        QBCore.Functions.Notify(Lang:t("notify.failed"), "error")
        isCrafting = false
    end)
end)

RegisterNetEvent('inventory:client:CraftAttachment', function(itemName, itemCosts, amount, toSlot, points)
    local ped = PlayerPedId()
    SendNUIMessage({ action = "close" })
    isCrafting = true
    QBCore.Functions.Progressbar("repair_vehicle", Lang:t("progress.crafting"), (math.random(2000, 5000) * amount), false, true, { disableMovement = true, disableCarMovement = true, disableMouse = false, disableCombat = true }, { animDict = "mini@repair", anim = "fixing_a_player", flags = 16 }, {}, {}, function()
        StopAnimTask(ped, "mini@repair", "fixing_a_player", 1.0)
        TriggerServerEvent("inventory:server:CraftAttachment", itemName, itemCosts, amount, toSlot, points)
        TriggerEvent('inventory:client:ItemBox', QBCore.Shared.Items[itemName], 'add')
        isCrafting = false
    end, function()
        StopAnimTask(ped, "mini@repair", "fixing_a_player", 1.0)
        QBCore.Functions.Notify(Lang:t("notify.failed"), "error")
        isCrafting = false
    end)
end)

RegisterNetEvent('inventory:client:PickupSnowballs', function()
    local ped = PlayerPedId()
    LoadAnimDict('anim@mp_snowball')
    TaskPlayAnim(ped, 'anim@mp_snowball', 'pickup_snowball', 3.0, 3.0, -1, 0, 1, 0, 0, 0)
    QBCore.Functions.Progressbar("pickupsnowball", Lang:t("progress.snowballs"), 1500, false, true, { disableMovement = true, disableCarMovement = true, disableMouse = false, disableCombat = true }, {}, {}, {}, function()
        ClearPedTasks(ped)
        TriggerServerEvent('inventory:server:snowball', 'add')
        TriggerEvent('inventory:client:ItemBox', QBCore.Shared.Items["snowball"], "add")
    end, function()
        ClearPedTasks(ped)
        QBCore.Functions.Notify(Lang:t("notify.canceled"), "error")
    end)
end)

RegisterNetEvent('inventory:client:UseSnowball', function(amount)
    local ped = PlayerPedId()
    GiveWeaponToPed(ped, `weapon_snowball`, amount, false, false)
    SetPedAmmo(ped, `weapon_snowball`, amount)
    SetCurrentPedWeapon(ped, `weapon_snowball`, true)
end)

RegisterNetEvent('inventory:client:UseWeapon', function(weaponData, shootbool)
    local ped = PlayerPedId()
    local weaponName = tostring(weaponData.name)
    local weaponHash = joaat(weaponData.name)
    if currentWeapon == weaponName then
        SetCurrentPedWeapon(ped, `WEAPON_UNARMED`, true)
        Wait(1500)
        RemoveAllPedWeapons(ped, true)
        TriggerEvent('weapons:client:SetCurrentWeapon', nil, shootbool)
        currentWeapon = nil
    elseif weaponName == "weapon_stickybomb" or weaponName == "weapon_pipebomb" or weaponName == "weapon_smokegrenade" or weaponName == "weapon_flare" or weaponName == "weapon_proxmine" or weaponName == "weapon_ball" or weaponName == "weapon_molotov" or weaponName == "weapon_grenade" or weaponName == "weapon_bzgas" then
        GiveWeaponToPed(ped, weaponHash, 1, false, false)
        SetPedAmmo(ped, weaponHash, 1)
        SetCurrentPedWeapon(ped, weaponHash, true)
        TriggerEvent('weapons:client:SetCurrentWeapon', weaponData, shootbool)
        currentWeapon = weaponName
    elseif weaponName == "weapon_snowball" then
        GiveWeaponToPed(ped, weaponHash, 10, false, false)
        SetPedAmmo(ped, weaponHash, 10)
        SetCurrentPedWeapon(ped, weaponHash, true)
        TriggerServerEvent('inventory:server:snowball', 'remove')
        TriggerEvent('weapons:client:SetCurrentWeapon', weaponData, shootbool)
        currentWeapon = weaponName
    elseif weaponName == "weapon_stungun" then
        local ammo = tonumber(weaponData.info.ammo) or 0
        GiveWeaponToPed(ped, weaponHash, ammo, false, false)
        SetPedAmmo(ped, weaponHash, ammo)
        SetCurrentPedWeapon(ped, weaponHash, true)
        TriggerEvent('weapons:client:SetCurrentWeapon', weaponData, shootbool)
        currentWeapon = weaponName
    else
        TriggerEvent('weapons:client:SetCurrentWeapon', weaponData, shootbool)
        local ammo = tonumber(weaponData.info.ammo) or 0
        if weaponName == "weapon_fireextinguisher" then ammo = 4000 end
        GiveWeaponToPed(ped, weaponHash, ammo, false, false)
        SetPedAmmo(ped, weaponHash, ammo)
        SetCurrentPedWeapon(ped, weaponHash, true)
        if weaponData.info.attachments then
            for _, attachment in pairs(weaponData.info.attachments) do
                GiveWeaponComponentToPed(ped, weaponHash, joaat(attachment.component))
            end
        end
        currentWeapon = weaponName
    end
end)

RegisterNetEvent('inventory:client:CheckWeapon', function(weaponName)
    if currentWeapon ~= weaponName:lower() then return end
    local ped = PlayerPedId()
    TriggerEvent('weapons:ResetHolster')
    SetCurrentPedWeapon(ped, `WEAPON_UNARMED`, true)
    RemoveAllPedWeapons(ped, true)
    currentWeapon = nil
end)

RegisterNetEvent('inventory:client:AddDropItem', function(dropId, player, coords) end)
RegisterNetEvent('inventory:client:RemoveDropItem', function(dropId) Drops[dropId] = nil; if Config.UseItemDrop then RemoveNearbyDrop(dropId) else DropsNear[dropId] = nil end end)

RegisterNetEvent('inventory:client:DropItemAnim', function()
    local ped = PlayerPedId()
    SendNUIMessage({ action = "close" })
    LoadAnimDict("pickup_object")
    TaskPlayAnim(ped, "pickup_object", "pickup_low", 8.0, -8.0, -1, 1, 0, false, false, false)
    Wait(2000)
    ClearPedTasks(ped)
end)

RegisterNetEvent('inventory:client:SetCurrentStash', function(stash) CurrentStash = stash end)

RegisterNetEvent('qb-inventory:client:giveAnim', function()
    if IsPedInAnyVehicle(PlayerPedId(), false) then return end
    LoadAnimDict('mp_common')
    TaskPlayAnim(PlayerPedId(), 'mp_common', 'givetake1_b', 8.0, 1.0, -1, 16, 0, 0, 0, 0)
end)

RegisterNetEvent('inventory:client:craftTarget', function()
    local crafting = { label = Lang:t("label.craft"), items = GetThresholdItems() }
    TriggerServerEvent("inventory:server:OpenInventory", "crafting", math.random(1, 99), crafting)
end)

RegisterNetEvent('inventory:client:GiveItemRemoveWeapon', function() SetCurrentPedWeapon(PlayerPedId(), 'WEAPON_UNARMED', true) end)

RegisterNetEvent('inventory:client:OpenTrash', function()
    local trashid = "" .. math.random(1000, 9999) .. math.random(1000, 9999) .. math.random(1000, 9999)
    TriggerServerEvent("inventory:server:OpenInventory", "stash", "Trash" .. trashid, { maxweight = 200000, slots = 5 }, false, true)
    TriggerEvent("inventory:client:SetCurrentStash", "Trash" .. trashid)
end)
--#endregion

--#region Commands
RegisterCommand('closeinv', closeInventory, false)

RegisterCommand('inventory', function()
    if not isCrafting and not inInventory then
        -- التحقق من وجود metadata قبل استخدامها
        local canOpen = false
        if PlayerData and PlayerData.metadata then
            canOpen = not (PlayerData.metadata.isdead or PlayerData.metadata.inlaststand or PlayerData.metadata.ishandcuffed) and not IsPauseMenuActive()
        else
            canOpen = not IsPauseMenuActive()
        end
        if canOpen then
            local ped = PlayerPedId()
            local curVeh = nil
            local VendingMachine = nil
            if not Config.UseTarget then VendingMachine = GetClosestVending() end
            if IsPedInAnyVehicle(ped, false) then
                local vehicle = GetVehiclePedIsIn(ped, false)
                CurrentGlovebox = QBCore.Functions.GetPlate(vehicle)
                curVeh = vehicle
                CurrentVehicle = nil
            else
                local vehicle = QBCore.Functions.GetClosestVehicle()
                if vehicle ~= 0 and vehicle ~= nil then
                    local pos = GetEntityCoords(ped)
                    local dimensionMin, dimensionMax = GetModelDimensions(GetEntityModel(vehicle))
                    local trunkpos = GetOffsetFromEntityInWorldCoords(vehicle, 0.0, dimensionMin.y, 0.0)
                    if IsBackEngine(GetEntityModel(vehicle)) then trunkpos = GetOffsetFromEntityInWorldCoords(vehicle, 0.0, dimensionMax.y, 0.0) end
                    if #(pos - trunkpos) < 1.5 and not IsPedInAnyVehicle(ped) then
                        if GetVehicleDoorLockStatus(vehicle) < 2 then
                            CurrentVehicle = QBCore.Functions.GetPlate(vehicle)
                            curVeh = vehicle
                            CurrentGlovebox = nil
                        else
                            QBCore.Functions.Notify(Lang:t("notify.vlocked"), "error")
                            return
                        end
                    else
                        CurrentVehicle = nil
                    end
                else
                    CurrentVehicle = nil
                end
            end
            if CurrentVehicle then
                local vehicleClass = GetVehicleClass(curVeh)
                local trunkConfig = Config.TrunkSpace[vehicleClass] or Config.TrunkSpace.default
                if trunkConfig then
                    local other = { maxweight = trunkConfig.maxWeight, slots = trunkConfig.slots }
                    TriggerServerEvent("inventory:server:OpenInventory", "trunk", CurrentVehicle, other)
                    OpenTrunk()
                end
            elseif CurrentGlovebox then
                TriggerServerEvent("inventory:server:OpenInventory", "glovebox", CurrentGlovebox)
            elseif CurrentDrop ~= 0 then
                TriggerServerEvent("inventory:server:OpenInventory", "drop", CurrentDrop)
            elseif VendingMachine then
                local ShopItems = { label = "Vending Machine", items = Config.VendingItem, slots = #Config.VendingItem }
                TriggerServerEvent("inventory:server:OpenInventory", "shop", "Vendingshop_" .. math.random(1, 99), ShopItems)
            else
                openAnim()
                TriggerServerEvent("inventory:server:OpenInventory")
            end
        end
    end
end, false)
RegisterKeyMapping('inventory', Lang:t("inf_mapping.opn_inv"), 'keyboard', 'TAB')

RegisterCommand('hotbar', function()
    isHotbar = not isHotbar
    if PlayerData and PlayerData.metadata then
        if not PlayerData.metadata.isdead and not PlayerData.metadata.inlaststand and not PlayerData.metadata.ishandcuffed and not IsPauseMenuActive() then
            ToggleHotbar(isHotbar)
        end
    else
        ToggleHotbar(isHotbar) -- افتحه حتى لو metadata غير موجود مؤقتاً
    end
end, false)
RegisterKeyMapping('hotbar', Lang:t("inf_mapping.tog_slots"), 'keyboard', 'z')

for i = 1, 5 do
    RegisterCommand('slot' .. i, function()
        if PlayerData and PlayerData.metadata then
            if not PlayerData.metadata.isdead and not PlayerData.metadata.inlaststand and not PlayerData.metadata.ishandcuffed and not IsPauseMenuActive() then
                TriggerServerEvent("inventory:server:UseItemSlot", i)
            end
        else
            TriggerServerEvent("inventory:server:UseItemSlot", i)
        end
    end, false)
    RegisterKeyMapping('slot' .. i, Lang:t("inf_mapping.use_item") .. i, 'keyboard', tostring(i))
end
--#endregion

--#region Trash Interactions
local TrashModel = { "prop_bin_05a", "prop_bin_01a", "v_ind_cfwaste", "prop_bin_08a", "prop_bin_08open", "prop_bin_02a", "prop_bin_03a", "prop_bin_04a", "prop_bin_06a", "prop_bin_07a", "prop_bin_07b", "prop_bin_07c", "prop_bin_07d", "prop_bin_10a", "prop_bin_10b", "prop_bin_11a", "prop_bin_11b", "prop_bin_12a" }
CreateThread(function()
    for k,v in pairs(TrashModel) do
        Wait(100)
        if exports.interact then
            exports.interact:AddModelInteraction({ model = v, offset = vec3(0.0, 0.0, 0.5), id = 'Trash' .. k, distance = 3.5, interactDst = 1.5, ignoreLos = false, options = { { label = 'Trash', event = "inventory:client:OpenTrash" } } })
        end
    end
end)
--#endregion

--#region Exports
exports("HasItem", HasItem)
exports("GetItemByName", GetItemByName)
--#endregion

-- Development Groupe
-- https://discord.gg/YFvBJPadda
-- By SK / SKANDI DEV
